package TrabajoFinal;

public class Main {
    public static void main(String[] args) {
        ArtefactosElec p1 = new ArtefactosElec("AECOMAG4QH","Cocina a gas Mabe 4hornillas",699.00,2);
        ArtefactosElec p2 = new ArtefactosElec("AETVLG55FHD","TV LG de 55pulg. UHD 4K Smart",1900.00,1);
        ropaYCalzado p3 = new ropaYCalzado("RCPAJDAS","Pantalon jean para dama, talla small",150.00,5);
        ropaYCalzado p4 = new ropaYCalzado("RCCAJHOcP","Casaca jean hombre con peluche",230.00,1);
        Muebles p5 = new Muebles("MUJCO6MACA","Juego de comedor 6 sillas, en Caoba",1600.00,0);
        Muebles p6 = new Muebles("MUMTV65ORG","Mesa de TV 65pulg. Con organizador",750.00,3);

        Empresa empresa = new Empresa();
        empresa.registrar(p1);
        empresa.registrar(p2);
        empresa.registrar(p3);
        empresa.registrar(p4);
        empresa.registrar(p5);
        empresa.registrar(p6);
        for (Productos p: empresa.getArregloProductos()) {
            System.out.println(p.toString());
        }
    }
}

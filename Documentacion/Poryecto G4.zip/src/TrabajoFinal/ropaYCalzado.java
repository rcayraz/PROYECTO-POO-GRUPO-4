package TrabajoFinal;

public class ropaYCalzado extends Productos {

    public ropaYCalzado(String codigo, String nombreProd, double precio, int stock) {
        super(codigo, nombreProd, precio, stock);
    }

    @Override
    public String toString() {
        return "ropaYCalzado{} " + super.toString();
    }
}

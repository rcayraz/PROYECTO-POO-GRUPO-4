package TrabajoFinal;

import java.util.ArrayList;
import java.util.List;

public class ManejoStock {

    private List<Productos> arregloProductos;

    public ManejoStock() {
        this.arregloProductos = new ArrayList<>();
    }

}
